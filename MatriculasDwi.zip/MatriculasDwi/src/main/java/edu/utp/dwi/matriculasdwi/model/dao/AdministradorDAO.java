package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Administrador;


import java.sql.*;
import java.util.ArrayList;

public class AdministradorDAO implements IAdministradorDAO{
    static Connection connection = DBConnection.getConnection();
    @Override
    public boolean addAdministrador(Administrador administrador) throws SQLException {
        String query = "{ CALL SP_AgregarAdministrador(?,?,?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, administrador.getAdmDni());
        statement.setString(2, administrador.getAdmUsuario());
        statement.setString(3, administrador.getAdmClave());
        statement.setString(4, administrador.getAdmNombres());
        statement.setString(5, administrador.getAdmApellidos());
        statement.setString(6, administrador.getAdmTelefono());
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public boolean updateAdministrador(Administrador administrador) throws SQLException {
        String query = "{ CALL SP_ActualizarAdministrador(?,?,?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, administrador.getAdmDni());
        statement.setString(2, administrador.getAdmUsuario());
        statement.setString(3, administrador.getAdmClave());
        statement.setString(4, administrador.getAdmNombres());
        statement.setString(5, administrador.getAdmApellidos());
        statement.setString(6, administrador.getAdmTelefono());
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public boolean deleteAdministrador(String dni) throws SQLException {
        String query = "{ CALL SP_EliminarAdministrador(?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, dni);
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public Administrador getAdministrador(String dni) throws SQLException {
        Administrador administrador = null;
        String query = "{ CALL SP_SelecionarAdministrador(?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, dni);
        ResultSet resultSet = statement.executeQuery();
        while(resultSet.next()) {
            administrador = new Administrador(
                    resultSet.getString("ADM_DNI"),
                    resultSet.getString("ADM_USUARIO"),
                    resultSet.getString("ADM_CLAVE"),
                    resultSet.getString("ADM_NOMBRES"),
                    resultSet.getString("ADM_APELLIDOS"),
                    resultSet.getString("ADM_TELEFONO")
            );
        }

        return administrador;
    }

    @Override
    public ArrayList<Administrador> listAdministrador() throws SQLException {
        String query="select * from administrador";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Administrador> administrador = new ArrayList<>();

        while (resultSet.next()) {
            administrador.add(new Administrador(
                    resultSet.getString("ADM_DNI"),
                    resultSet.getString("ADM_USUARIO"),
                    resultSet.getString("ADM_CLAVE"),
                    resultSet.getString("ADM_NOMBRES"),
                    resultSet.getString("ADM_APELLIDOS"),
                    resultSet.getString("ADM_TELEFONO")
            ));

        }
        return administrador;
    }


}
