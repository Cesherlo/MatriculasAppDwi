package edu.utp.dwi.matriculasdwi.controller;

import edu.utp.dwi.matriculasdwi.model.Login;
import edu.utp.dwi.matriculasdwi.model.dao.DBConnection;
import edu.utp.dwi.matriculasdwi.model.dao.LoginDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@WebServlet(name = "LoginController", value = "/LoginController")
public class LoginController extends HttpServlet {
    private LoginDAO loginDAO;
    public void init() {
        loginDAO = new LoginDAO();
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        Login login = new Login();
        login.setUsuario(username);
        login.setClave(password);

        try {
            if (loginDAO.validar(login)) {
                //HttpSession session = request.getSession();
                // session.setAttribute("username",username);
                response.sendRedirect("AlumnoController?accion=listar");
            } else {
                HttpSession session = request.getSession();
                request.setAttribute("mensaje", "Datos Incorrectos");
                request.getRequestDispatcher("InicioSesion.jsp").forward(request, response);
            }
        }  catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}