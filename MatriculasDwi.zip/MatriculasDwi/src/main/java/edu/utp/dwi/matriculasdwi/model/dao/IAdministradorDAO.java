package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Administrador;

import java.sql.SQLException;
import java.util.ArrayList;

public interface IAdministradorDAO {

    boolean addAdministrador(Administrador administrador) throws SQLException;

    boolean updateAdministrador(Administrador administrador)  throws SQLException;

    boolean deleteAdministrador(String dni) throws SQLException;

    Administrador getAdministrador(String dni) throws SQLException;

    ArrayList<Administrador> listAdministrador() throws SQLException;


}
