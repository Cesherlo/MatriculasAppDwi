package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Grado;
import edu.utp.dwi.matriculasdwi.model.Profesor;

import java.sql.*;
import java.util.ArrayList;

public class GradoDAO implements IGradoDAO {
    static Connection connection = DBConnection.getConnection();

    @Override
    public boolean addGrado(Grado grado) throws SQLException {
        String query = "{ CALL SP_AgregarGrado(?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, grado.generarIdGrado());
        statement.setString(2, grado.getGradoNombre());
        statement.setString(3, grado.getProfesorDni());
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public boolean updateGrado(Grado grado) throws SQLException {
        String query = "{ CALL SP_ActualizarGrado(?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, grado.getGradoId());
        statement.setString(2, grado.getGradoNombre());
        statement.setString(3, grado.getProfesorDni());
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public ArrayList<Grado> listGrado() throws SQLException {
        String query="select G.GRADO_ID , G.GRADO_NOMBRE ,G.PROFESOR_DNI , P.PROFESOR_NOMBRES, P.PROFESOR_APELLIDOS " +
                "from grado AS G INNER JOIN PROFESOR AS P WHERE G.PROFESOR_DNI = P.PROFESOR_DNI";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Grado> grado = new ArrayList<>();

        while (resultSet.next()) {
            grado.add(new Grado(
                    resultSet.getString("GRADO_ID"),
                    resultSet.getString("GRADO_NOMBRE"),
                    resultSet.getString("PROFESOR_DNI"),
                    resultSet.getString("PROFESOR_NOMBRES"),
                    resultSet.getString("PROFESOR_APELLIDOS")
            ));

        }
        return grado;
    }

    @Override
    public Grado getGradoId(String id) throws SQLException {
        Grado grado = null;
        String query = "{ CALL SP_SeleccionarGrado(?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, id);
        ResultSet resultSet = statement.executeQuery();

        while(resultSet.next()) {
            grado = new Grado(
                    resultSet.getString("GRADO_ID"),
                    resultSet.getString("GRADO_NOMBRE"),
                    resultSet.getString("PROFESOR_DNI")
            );
        }
        return grado;
    }

    @Override
    public boolean deleteGrado(String id) throws SQLException {
        String query = "{ CALL SP_EliminarGrado(?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, id);
        statement.execute();
        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }
}
