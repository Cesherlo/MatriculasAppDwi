package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Alumno;

import java.sql.SQLException;
import java.util.ArrayList;

public interface IAlumnoApoderadoDAO {
    //Insertar alumno
    boolean addAlumno( Alumno alumno) throws SQLException;

    // Actualizar alumno
    boolean updateAlumno(Alumno alumno) throws SQLException;

    // Eliminar alumno en la tabla
    boolean deleteAlumno(int dni) throws SQLException;

    // Selecionar un alumno
    Alumno getAlumno(int dni) throws SQLException;

    // Selecionar todos los alumno
    ArrayList<Alumno> listAlumno() throws SQLException;
}
