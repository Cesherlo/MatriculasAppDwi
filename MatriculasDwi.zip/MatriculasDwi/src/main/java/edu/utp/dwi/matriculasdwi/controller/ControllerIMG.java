package edu.utp.dwi.matriculasdwi.controller;

import edu.utp.dwi.matriculasdwi.model.dao.AlumnoApoderadoDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "ControllerIMG", value = "/ControllerIMG")
public class ControllerIMG extends HttpServlet {
    AlumnoApoderadoDAO alumnodao=new AlumnoApoderadoDAO();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            int dni = Integer.parseInt(request.getParameter("dni"));
            alumnodao.listarImg(dni, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
