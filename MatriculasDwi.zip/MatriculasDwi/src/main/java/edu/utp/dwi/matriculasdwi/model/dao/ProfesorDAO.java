package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Profesor;

import java.sql.*;
import java.util.ArrayList;


public class ProfesorDAO implements IProfesorDAO{
    static Connection connection = DBConnection.getConnection();

    @Override
    public boolean addProfesor(Profesor profesor) throws SQLException {
        String query = "{ CALL SP_AgregarProfesor(?,?,?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, profesor.getDni());
        statement.setString(2, profesor.getNombres());
        statement.setString(3, profesor.getApellidos());
        statement.setString(4, profesor.getTelefono());
        statement.setString(5, profesor.getDistrito());
        statement.setString(6, profesor.getDireccion());
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public boolean updateProfesor(Profesor profesor) throws SQLException {
        String query = "{ CALL SP_ActualizarProfesor(?,?,?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, profesor.getDni());
        statement.setString(2, profesor.getNombres());
        statement.setString(3, profesor.getApellidos());
        statement.setString(4, profesor.getTelefono());
        statement.setString(5, profesor.getDistrito());
        statement.setString(6, profesor.getDireccion());
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }


    @Override
    public boolean deleteProfesor(String dni) throws SQLException {
        String query = "{ CALL SP_EliminarProfesor(?) }";

        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, dni);

        statement.execute();
        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public Profesor getProfesor(String dni) throws SQLException {
        Profesor profesor = null;
        String query = "SELECT * FROM PROFESOR WHERE PROFESOR_DNI=" + dni;
        PreparedStatement pStatement = connection.prepareStatement(query);
        ResultSet resultSet = pStatement.executeQuery();
        while(resultSet.next()) {
            profesor = new Profesor(
                    resultSet.getString("PROFESOR_DNI"),
                    resultSet.getString("PROFESOR_NOMBRES"),
                    resultSet.getString("PROFESOR_APELLIDOS"),
                    resultSet.getString("PROFESOR_TELEFONO"),
                    resultSet.getString("PROFESOR_DISTRITO"),
                    resultSet.getString("PROFESOR_DIRECCION")
            );
        }
            return profesor;
    }

    @Override
    public ArrayList<Profesor> listProfesor() throws SQLException {
        String query="select * from profesor";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Profesor> profesores = new ArrayList<>();

        while (resultSet.next()) {
            profesores.add(new Profesor(
                    resultSet.getString("PROFESOR_DNI"),
                    resultSet.getString("PROFESOR_NOMBRES"),
                    resultSet.getString("PROFESOR_APELLIDOS"),
                    resultSet.getString("PROFESOR_TELEFONO"),
                    resultSet.getString("PROFESOR_DISTRITO"),
                    resultSet.getString("PROFESOR_DIRECCION")
            ));

        }
        return profesores;
    }

}
