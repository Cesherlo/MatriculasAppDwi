package edu.utp.dwi.matriculasdwi.controller;

import edu.utp.dwi.matriculasdwi.model.Administrador;
import edu.utp.dwi.matriculasdwi.model.dao.AdministradorDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "AdministradorController", value = "/AdministradorController")
public class AdministradorController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("get", request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("post", request, response);
    }

    protected void processRequest(String method, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = "listar";
        if (request.getParameter("accion") != null) {
            accion = request.getParameter("accion");
        }
        String dni="";
        if (request.getParameter("dni") != null) {
            dni = request.getParameter("dni");
        }
        AdministradorDAO administradorDAO = new AdministradorDAO();
        try {
            if(method == "get"){
                switch (accion){
                    case "listar":
                        listaAdministrador(request, response, administradorDAO.listAdministrador());
                        request.getRequestDispatcher("view/Administrador.jsp").forward(request, response);
                        break;
                    case "editar":
                        setViewContent(request, dni != null ? administradorDAO.getAdministrador(dni) : new Administrador());
                        request.getRequestDispatcher("view/EditarAdministrador.jsp").forward(request, response);
                        break;
                    case "eliminar":
                        administradorDAO.deleteAdministrador(dni);
                        listaAdministrador(request, response, administradorDAO.listAdministrador());
                        request.getRequestDispatcher("view/Administrador.jsp").forward(request, response);
                        break;


                }

            } else {
                switch (accion){
                    case "save":
                        if (administradorDAO.addAdministrador(getAdministradorFromForm(request))) {
                            listaAdministrador(request, response, administradorDAO.listAdministrador());
                            request.getRequestDispatcher("view/Administrador.jsp").forward(request, response);

                        }else {
                            setViewContent(request, administradorDAO.getAdministrador(dni));
                            request.getRequestDispatcher("view/EditarAdministrador.jsp").forward(request, response);
                        }
                        break;
                    case "update":
                        if (administradorDAO.updateAdministrador(getAdministradorFromForm(request))) {
                            listaAdministrador(request, response, administradorDAO.listAdministrador());
                            request.getRequestDispatcher("view/Administrador.jsp").forward(request, response);
                        } else {
                            setViewContent(request, administradorDAO.getAdministrador(dni));
                            request.getRequestDispatcher("view/EditarAdministrador.jsp").forward(request, response);
                        }
                        break;

                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }



    private void listaAdministrador(HttpServletRequest request, HttpServletResponse response, ArrayList<Administrador> administrador) throws ServletException, IOException {
        request.setAttribute("administrador", administrador);
    }
    private void setViewContent(HttpServletRequest request, Administrador administrador) throws SQLException {
        request.setAttribute("administrador", administrador);
    }
    private Administrador getAdministradorFromForm(HttpServletRequest request) {
        Administrador administrador = new Administrador();
        administrador.setAdmDni(request.getParameter("txtdni"));
        administrador.setAdmUsuario(request.getParameter("txtusuario"));
        administrador.setAdmClave(request.getParameter("txtclave"));
        administrador.setAdmNombres(request.getParameter("txtnom"));
        administrador.setAdmApellidos(request.getParameter("txtape"));
        administrador.setAdmTelefono(request.getParameter("txtTelf"));

        return administrador;
    }


}
