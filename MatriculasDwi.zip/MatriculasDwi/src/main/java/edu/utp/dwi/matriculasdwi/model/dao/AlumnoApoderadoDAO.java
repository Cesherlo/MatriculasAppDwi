package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Alumno;

import javax.servlet.http.HttpServletResponse;
import javax.swing.*;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.Buffer;
import java.sql.*;
import java.util.ArrayList;

public class AlumnoApoderadoDAO implements IAlumnoApoderadoDAO {
    static Connection connection = DBConnection.getConnection();
    @Override
    public boolean addAlumno(Alumno alumno) throws SQLException {
        String query = "{ CALL SP_AgregarAlumnos(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setInt(1, alumno.getAlumDni());
        statement.setString(2, alumno.getAlumNom());
        statement.setString(3, alumno.getAlumApe());
        statement.setString(4, alumno.getAlumNac());
        statement.setString(5, alumno.getAlunGen());
        statement.setString(6, alumno.getAlumDis());
        statement.setString(7, alumno.getAlumDir());
        statement.setString(8, alumno.getAlumPro());
        statement.setInt(9, alumno.getAlumTel());
        statement.setString(10, alumno.getAlumCorreo());
        statement.setBinaryStream(11, alumno.getAlumFoto());
        statement.setString(12, alumno.getAlumObs());
        statement.setInt(13, alumno.getApodDni());
        statement.setString(14, alumno.getApodNomb());
        statement.setString(15, alumno.getApodApel());
        statement.setString(16, alumno.getApodNac());
        statement.setString(17, alumno.getApodGen());
        statement.setInt(18, alumno.getApodTel());
        statement.setString(19, alumno.getApodCor());
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public boolean updateAlumno(Alumno alumno) throws SQLException {
        String query = "{ CALL SP_ActualizarAlumnos(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setInt(1, alumno.getAlumDni());
        statement.setString(2, alumno.getAlumNom());
        statement.setString(3, alumno.getAlumApe());
        statement.setString(4, alumno.getAlumNac());
        statement.setString(5, alumno.getAlunGen());
        statement.setString(6, alumno.getAlumDis());
        statement.setString(7, alumno.getAlumDir());
        statement.setString(8, alumno.getAlumPro());
        statement.setInt(9, alumno.getAlumTel());
        statement.setString(10, alumno.getAlumCorreo());
        statement.setBinaryStream(11, alumno.getAlumFoto());
        statement.setString(12, alumno.getAlumObs());
        statement.setInt(13, alumno.getApodDni());
        statement.setString(14, alumno.getApodNomb());
        statement.setString(15, alumno.getApodApel());
        statement.setString(16, alumno.getApodNac());
        statement.setString(17, alumno.getApodGen());
        statement.setInt(18, alumno.getApodTel());
        statement.setString(19, alumno.getApodCor());
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public boolean deleteAlumno(int dni) throws SQLException {
        String query = "{ CALL SP_EliminarAlumno(?) }";

        CallableStatement statement = connection.prepareCall(query);
        statement.setInt(1, dni);

        statement.execute();
        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public Alumno getAlumno(int dni) throws SQLException {
        Alumno alumno = null;
        String query = "select al.* , ap.* from alumno as al  inner join  " +
                "apoderado as ap on al.ALUMNO_DNI = ap.ALUMNO_DNI where al.alumno_dni =" + dni;
        PreparedStatement pStatement = connection.prepareStatement(query);
        ResultSet resultSet = pStatement.executeQuery();
        while(resultSet.next()) {
            alumno = new Alumno(
                    resultSet.getInt("ALUMNO_DNI"),
                    resultSet.getString("ALUMNO_NOMBRES"),
                    resultSet.getString("ALUMNO_APELLIDOS"),
                    resultSet.getString("ALUMNO_FECHA_NACIMIENTO"),
                    resultSet.getString("ALUMNO_GENERO"),
                    resultSet.getString("ALUMNO_DISTRITO"),
                    resultSet.getString("ALUMNO_DIRECCION"),
                    resultSet.getString("ALUMNO_PROCEDENCIA"),
                    resultSet.getInt("ALUMNO_TELEFONO"),
                    resultSet.getString("ALUMNO_CORREO"),
                    resultSet.getBinaryStream("ALUMNO_FOTO"),
                    resultSet.getString("ALUMNO_OBSERVACIONES"),
                    resultSet.getInt("APODERADO_DNI"),
                    resultSet.getString("APODERADO_NOMBRES"),
                    resultSet.getString("APODERADO_APELLIDOS"),
                    resultSet.getString("APODERADO_FECHA_NACIMIENTO"),
                    resultSet.getString("APODERADO_GENERO"),
                    resultSet.getInt("APODERADO_TELEFONO"),
                    resultSet.getString("APODERADO_CORREO")
            );
        }

        return alumno;
    }

    @Override
    public ArrayList<Alumno> listAlumno() throws SQLException {
        String query="select * from alumno";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Alumno> alumnos = new ArrayList<>();

        while (resultSet.next()) {
            alumnos.add(new Alumno(
                    resultSet.getInt("ALUMNO_DNI"),
                    resultSet.getString("ALUMNO_NOMBRES"),
                    resultSet.getString("ALUMNO_APELLIDOS"),
                    resultSet.getString("ALUMNO_FECHA_NACIMIENTO"),
                    resultSet.getString("ALUMNO_GENERO"),
                    resultSet.getString("ALUMNO_DISTRITO"),
                    resultSet.getString("ALUMNO_DIRECCION"),
                    resultSet.getString("ALUMNO_PROCEDENCIA"),
                    resultSet.getInt("ALUMNO_TELEFONO"),
                    resultSet.getString("ALUMNO_CORREO"),
                    resultSet.getBinaryStream("ALUMNO_FOTO"),
                    resultSet.getString("ALUMNO_OBSERVACIONES")
            ));

        }
        return alumnos;
    }

    public void listarImg(int dni, HttpServletResponse response){
        String sql = "select ALUMNO_FOTO from ALUMNO WHERE ALUMNO_DNI=" + dni;
        InputStream inputStream = null;
        OutputStream outputStream = null;
        BufferedInputStream bufferedInputStream = null;
        BufferedOutputStream bufferedOutputStream = null;
        response.setContentType("image/*");
        try {
            outputStream = response.getOutputStream();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                    inputStream = resultSet.getBinaryStream("ALUMNO_FOTO");
            }
            bufferedInputStream = new BufferedInputStream(inputStream);
            bufferedOutputStream = new BufferedOutputStream(outputStream);
            int i = 0;
            while ((i=bufferedInputStream.read()) != -1){
                bufferedOutputStream.write(i);
            }

        } catch (Exception e){

        }

    }


}
