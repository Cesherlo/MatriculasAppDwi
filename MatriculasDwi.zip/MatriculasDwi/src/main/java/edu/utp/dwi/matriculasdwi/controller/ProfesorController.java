package edu.utp.dwi.matriculasdwi.controller;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Profesor;
import edu.utp.dwi.matriculasdwi.model.dao.ProfesorDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "ProfesorController", value = "/ProfesorController")
public class ProfesorController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("get", request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("post", request, response);
    }

    protected void processRequest(String method, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = "listar";
        if (request.getParameter("accion") != null) {
            accion = request.getParameter("accion");
        }
        String dni = "";
        if (request.getParameter("dni") != null) {
            dni = request.getParameter("dni");
        }
        ProfesorDAO profesorDAO = new ProfesorDAO();

        try {
            if(method == "get"){
                switch (accion){
                    case "listar":
                        listaProfesores(request, response, profesorDAO.listProfesor());
                        break;
                    case "editar":
                        setViewContent(request, dni != null ? profesorDAO.getProfesor(dni) : new Profesor());
                        request.getRequestDispatcher("view/EditarProfesor.jsp").forward(request, response);
                        break;
                    case "eliminar":
                        profesorDAO.deleteProfesor(dni);
                        listaProfesores(request, response, profesorDAO.listProfesor());
                        break;
                }

            } else {
                switch (accion) {
                    case "save":
                        if (profesorDAO.addProfesor(getProfesorFromForm(request))) {
                            listaProfesores(request, response, profesorDAO.listProfesor());
                        } else {
                            setViewContent(request, profesorDAO.getProfesor(dni));
                            request.getRequestDispatcher("view/EditarProfesor.jsp").forward(request, response);
                        }
                        break;
                    case "update":
                        if (profesorDAO.updateProfesor(getProfesorFromForm(request))) {
                            listaProfesores(request, response, profesorDAO.listProfesor());
                            request.getRequestDispatcher("view/Profesores.jsp").forward(request, response);
                        } else {
                            setViewContent(request, profesorDAO.getProfesor(dni));
                            request.getRequestDispatcher("view/EditarProfesor.jsp").forward(request, response);
                        }
                        break;
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void setViewContent(HttpServletRequest request, Profesor profesor) throws SQLException {
        request.setAttribute("profesor", profesor);
    }

    private void listaProfesores(HttpServletRequest request, HttpServletResponse response, ArrayList<Profesor> profesores) throws ServletException, IOException {
        request.setAttribute("profesores", profesores);
        request.getRequestDispatcher("view/Profesores.jsp").forward(request, response);
    }

    private Profesor getProfesorFromForm(HttpServletRequest request) {
        Profesor profesor = new Profesor();
        profesor.setDni(request.getParameter("txtdni"));
        profesor.setNombres(request.getParameter("txtnom"));
        profesor.setApellidos(request.getParameter("txtape"));
        profesor.setTelefono(request.getParameter("txtTelf"));
        profesor.setDistrito(request.getParameter("txtDist"));
        profesor.setDireccion(request.getParameter("txtDir"));
        return profesor;
    }
}
