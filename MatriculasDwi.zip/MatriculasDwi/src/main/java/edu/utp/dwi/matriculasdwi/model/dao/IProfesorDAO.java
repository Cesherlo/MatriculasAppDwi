package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Profesor;

import java.sql.SQLException;
import java.util.ArrayList;

public interface IProfesorDAO {
    //Insertar Profesor
    boolean addProfesor(Profesor profesor) throws SQLException;

    // Actualizar Profesor
    boolean updateProfesor(Profesor profesor) throws SQLException;


    // Eliminar Profesor en la tabla
    boolean deleteProfesor(String dni) throws SQLException;

    // Selecionar un PROFESOR
    Profesor getProfesor(String dni) throws SQLException;

    // Selecionar todos los Profesores
    ArrayList<Profesor> listProfesor() throws SQLException;
}
