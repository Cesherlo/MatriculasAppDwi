package edu.utp.dwi.matriculasdwi.model;

public class Grado {
    String gradoId;
    String gradoNombre;
    String profesorDni;
    String profesorNombre;
    String profesorApellido;

    public Grado(String gradoId, String gradoNombre, String profesorDni) {
        this.gradoId = gradoId;
        this.gradoNombre = gradoNombre;
        this.profesorDni = profesorDni;
    }

    public Grado(String gradoId, String gradoNombre, String profesorDni, String profesorNombre, String profesorApelldio) {
        this.gradoId = gradoId;
        this.gradoNombre = gradoNombre;
        this.profesorDni = profesorDni;
        this.profesorNombre = profesorNombre;
        this.profesorApellido = profesorApelldio;
    }

    public Grado() {

    }
    public String generarIdGrado(){
        String id="";
        int random = (int)(Math.random()*(999-100+1)+100);
        id = "GRA"+random;
        return id;
    }

    public String getProfesorApellido() {
        return profesorApellido;
    }

    public void setProfesorApellido(String profesorApellido) {
        this.profesorApellido = profesorApellido;
    }

    public String getGradoId() {
        return gradoId;
    }

    public void setGradoId(String gradoId) {
        this.gradoId = gradoId;
    }

    public String getGradoNombre() {
        return gradoNombre;
    }

    public void setGradoNombre(String gradoNombre) {
        this.gradoNombre = gradoNombre;
    }

    public String getProfesorDni() {
        return profesorDni;
    }

    public void setProfesorDni(String profesorDni) {
        this.profesorDni = profesorDni;
    }

    public String getProfesorNombre() {
        return profesorNombre;
    }

    public void setProfesorNombre(String profesorNombre) {
        this.profesorNombre = profesorNombre;
    }
}
