package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Grado;


import java.sql.SQLException;
import java.util.ArrayList;

public interface IGradoDAO {

    boolean addGrado(Grado grado) throws SQLException;

    boolean updateGrado(Grado grado) throws SQLException;

    ArrayList<Grado> listGrado() throws SQLException;

    Grado getGradoId(String id) throws SQLException;

    boolean deleteGrado(String id) throws SQLException;
}
