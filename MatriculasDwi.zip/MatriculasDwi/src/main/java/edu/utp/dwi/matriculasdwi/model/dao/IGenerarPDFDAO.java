package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.GenerarPDF;

import java.sql.SQLException;

public interface IGenerarPDFDAO {
   GenerarPDF getRegistro(String matriculaID) throws SQLException;
}
