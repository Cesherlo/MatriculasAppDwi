package edu.utp.dwi.matriculasdwi.controller;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.dao.AlumnoApoderadoDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "AlumnoController", value = "/AlumnoController")
public class AlumnoController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("get", request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("post", request, response);
    }

    protected void processRequest(String method, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = "listar";
        if (request.getParameter("accion") != null) {
            accion = request.getParameter("accion");
        }
        int id = 0;
        if (request.getParameter("id") != null) {
            id = Integer.parseInt(request.getParameter("id"));
        }
        AlumnoApoderadoDAO alumnoDAO = new AlumnoApoderadoDAO();
        try {
            if(method == "get"){
                switch (accion){
                    case "listar":
                        listaAlumnos(request, response, alumnoDAO.listAlumno());
                        break;
                    case "editar":
                        setViewContent(request, id > 0 ? alumnoDAO.getAlumno(id) : new Alumno());
                        request.getRequestDispatcher("view/EditarAlumno.jsp").forward(request, response);
                        break;
                    case "eliminar":
                        alumnoDAO.deleteAlumno(id);
                        listaAlumnos(request, response, alumnoDAO.listAlumno());
                        break;

                }

            }else {
                switch (accion) {
                    case "save":
                        if (alumnoDAO.addAlumno(getAlumnoFromForm(request))) {
                            listaAlumnos(request, response, alumnoDAO.listAlumno());
                        } else {
                            setViewContent(request, alumnoDAO.getAlumno(id));
                            request.getRequestDispatcher("view/EditarAlumno.jsp").forward(request, response);
                        }
                        break;
                    case "update":
                        if (alumnoDAO.updateAlumno(getAlumnoFromForm(request))) {
                            listaAlumnos(request, response, alumnoDAO.listAlumno());
                            request.getRequestDispatcher("view/Alumnos.jsp").forward(request, response);
                        } else {
                            setViewContent(request, alumnoDAO.getAlumno(id));
                            request.getRequestDispatcher("view/EditarAlumno.jsp").forward(request, response);
                        }
                        break;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
    private void setViewContent(HttpServletRequest request, Alumno alumno) throws SQLException {
        request.setAttribute("alumno", alumno);
    }
    private void listaAlumnos(HttpServletRequest request, HttpServletResponse response, ArrayList<Alumno> alumnos) throws ServletException, IOException {
        request.setAttribute("alumnos", alumnos);
        request.getRequestDispatcher("view/Alumnos.jsp").forward(request, response);
    }
    private Alumno getAlumnoFromForm(HttpServletRequest request) {
        Alumno alumno = new Alumno();
        InputStream input = new ByteArrayInputStream(request.getParameter("txtFoto").getBytes(StandardCharsets.UTF_8));
        alumno.setAlumDni(Integer.parseInt(request.getParameter("txtDni")));
        alumno.setAlumNom(request.getParameter("txtNombre"));
        alumno.setAlumApe(request.getParameter("txtApellido"));
        alumno.setAlumNac(request.getParameter("txtFecNac"));
        alumno.setAlunGen(request.getParameter("txtGenero"));
        alumno.setAlumDis(request.getParameter("txtDistrito"));
        alumno.setAlumDir(request.getParameter("txtDireccion"));
        alumno.setAlumPro(request.getParameter("txtProc"));
        alumno.setAlumTel(Integer.parseInt(request.getParameter("txtTelf")));
        alumno.setAlumCorreo(request.getParameter("txtCorreo"));
        alumno.setAlumFoto(input);
        alumno.setAlumObs(request.getParameter("txtObs"));
        alumno.setApodDni(Integer.parseInt(request.getParameter("txtApoDni")));
        alumno.setApodNomb(request.getParameter("txtApoNom"));
        alumno.setApodApel(request.getParameter("txtApoApe"));
        alumno.setApodNac(request.getParameter("txtApoFec"));
        alumno.setApodGen(request.getParameter("txtApoGen"));
        alumno.setApodTel(Integer.parseInt(request.getParameter("txtApoTelf")));
        alumno.setApodCor(request.getParameter("txtApoCorreo"));


        return alumno;
    }
}
