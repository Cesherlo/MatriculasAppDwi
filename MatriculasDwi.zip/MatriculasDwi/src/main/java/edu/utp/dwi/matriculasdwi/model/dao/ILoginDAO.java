package edu.utp.dwi.matriculasdwi.model.dao;


import edu.utp.dwi.matriculasdwi.model.Login;

import java.sql.SQLException;

public interface ILoginDAO {
    boolean validar(Login login) throws ClassNotFoundException;

}
