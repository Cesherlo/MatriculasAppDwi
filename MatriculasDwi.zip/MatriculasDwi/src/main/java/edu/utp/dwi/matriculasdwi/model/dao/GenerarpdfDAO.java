package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.GenerarPDF;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GenerarpdfDAO implements IGenerarPDFDAO{
    static Connection connection = DBConnection.getConnection();
    @Override
    public GenerarPDF getRegistro(String matriculaID) throws SQLException {

            GenerarPDF generarPDFDAO=null;
            String query = "{ CALL SP_GENERARPDF(?) }";
            CallableStatement statement = connection.prepareCall(query);
            statement.setString(1, matriculaID);
            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()) {
                generarPDFDAO = new GenerarPDF(
                        resultSet.getString("ALUMNO_DNI"),
                        resultSet.getString("ALUMNO_NOMBRES"),
                        resultSet.getString("ALUMNO_APELLIDOS"),
                        resultSet.getString("ALUMNO_FECHA_NACIMIENTO"),
                        resultSet.getString("ALUMNO_DISTRITO"),
                        resultSet.getString("ALUMNO_DIRECCION"),
                        resultSet.getString("ALUMNO_PROCEDENCIA"),
                        resultSet.getString("ALUMNO_TELEFONO"),
                        resultSet.getString("APODERADO_DNI"),
                        resultSet.getString("APODERADO_NOMBRES"),
                        resultSet.getString("APODERADO_APELLIDOS"),
                        resultSet.getString("APODERADO_FECHA_NACIMIENTO"),
                        resultSet.getString("APODERADO_TELEFONO"),
                        resultSet.getString("MATRICULA_ID"),
                        resultSet.getString("MATRICULA_FECHA"),
                        resultSet.getString("GRADO_NOMBRE"),
                        resultSet.getString("PROFESOR_NOMBRES"),
                        resultSet.getString("PROFESOR_APELLIDOS")
                );
            }
            return generarPDFDAO;
        }
}

