package edu.utp.dwi.matriculasdwi.controller;


import edu.utp.dwi.matriculasdwi.model.Grado;
import edu.utp.dwi.matriculasdwi.model.Matricula;
import edu.utp.dwi.matriculasdwi.model.Pago;
import edu.utp.dwi.matriculasdwi.model.dao.GradoDAO;
import edu.utp.dwi.matriculasdwi.model.dao.MatriculaDAO;
import edu.utp.dwi.matriculasdwi.model.dao.PagoDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "MatriculaController", value = "/MatriculaController")
public class MatriculaController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("get", request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("post", request, response);

    }
    protected void processRequest(String method, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = "listar";
        if (request.getParameter("accion") != null) {
            accion = request.getParameter("accion");
        }
        String id = "";
        if (request.getParameter("id") != null) {
            id = request.getParameter("id");
        }

        MatriculaDAO matriculaDAO = new MatriculaDAO();
        GradoDAO gradoDAO = new GradoDAO();
        PagoDAO pagoDAO = new PagoDAO();

        try {
            if(method == "get"){
                switch (accion){
                    case "listar":
                        listaMatriculas(request, response, matriculaDAO.listMatricula());
                        break;
                    case "editar":
                        setViewContent(request, id.length() > 1 ? matriculaDAO.getMatriculaId(id) : new Matricula());
                        listaGrado(request, response, gradoDAO.listGrado());
                        listaPago(request, response, pagoDAO.listPago());
                        request.getRequestDispatcher("view/EditarMatricula.jsp").forward(request, response);
                        break;
                    case "eliminar":
                        matriculaDAO.deleteMatricula(id);
                        listaMatriculas(request, response, matriculaDAO.listMatricula());
                        break;
                    case "buscar":
                        BuscaMatriculas(request, response, matriculaDAO.BuscaMatricula(id));
                        break;
                }

            } else {
                switch (accion) {
                    case "save":
                        if (matriculaDAO.addMatricula(getMatriculaFromForm(request))) {
                            listaMatriculas(request, response, matriculaDAO.listMatricula());
                        } else {
                            setViewContent(request, matriculaDAO.getMatriculaId(id));
                            request.getRequestDispatcher("view/EditarMatricula.jsp").forward(request, response);
                        }
                        break;
                    case "update":
                        if (matriculaDAO.updateMatricula(getMatriculaFromForm(request))) {
                            listaMatriculas(request, response, matriculaDAO.listMatricula());
                        } else {
                            setViewContent(request, matriculaDAO.getMatriculaId(id));
                            request.getRequestDispatcher("view/EditarMatricula.jsp").forward(request, response);
                        }
                        break;
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void setViewContent(HttpServletRequest request, Matricula matricula) throws SQLException {
        request.setAttribute("matricula", matricula);
    }

    private void listaMatriculas(HttpServletRequest request, HttpServletResponse response, ArrayList<Matricula> matricula) throws ServletException, IOException {
        request.setAttribute("matricula", matricula);
        request.getRequestDispatcher("view/Matriculas.jsp").forward(request, response);
    }
    private void BuscaMatriculas(HttpServletRequest request, HttpServletResponse response, ArrayList<Matricula> matricula) throws ServletException, IOException {
        request.setAttribute("matricula", matricula);
        request.getRequestDispatcher("view/Matriculas.jsp").forward(request, response);
    }
    private void listaGrado(HttpServletRequest request, HttpServletResponse response, ArrayList<Grado> grado) throws ServletException, IOException {
        request.setAttribute("grado", grado);
    }
    private void listaPago(HttpServletRequest request, HttpServletResponse response, ArrayList<Pago> pago) throws ServletException, IOException {
        request.setAttribute("pago", pago);
    }
    private Matricula getMatriculaFromForm(HttpServletRequest request) {
        Matricula matricula = new Matricula();
        matricula.setMatriculaId(request.getParameter("txtIdMatricula"));
        matricula.setGradoId(request.getParameter("txtIdGrado"));
        matricula.setMatriculaFecha(request.getParameter("txtFecha"));
        matricula.setPagoId(request.getParameter("txtPagoId"));
        return matricula;
    }

}
