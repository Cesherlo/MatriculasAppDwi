package edu.utp.dwi.matriculasdwi.controller;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Pago;
import edu.utp.dwi.matriculasdwi.model.Profesor;
import edu.utp.dwi.matriculasdwi.model.dao.PagoDAO;
import edu.utp.dwi.matriculasdwi.model.dao.ProfesorDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "PagoController", value = "/PagoController")
public class PagoController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("get", request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("post", request, response);
    }

    protected void processRequest(String method, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = "listar";
        if (request.getParameter("accion") != null) {
            accion = request.getParameter("accion");
        }
        int idPago = 0;
        if (request.getParameter("idPago") != null) {
            idPago = Integer.parseInt(request.getParameter("idPago"));
        }
        PagoDAO pagoDAO = new PagoDAO();
        try {
            if(method == "get"){
                switch (accion){
                    case "listar":
                        listaPagos(request, response, pagoDAO.listPago());
                        break;
                    case "editar":
                        setViewContent(request, idPago > 0 ? pagoDAO.getPago(idPago) : new Pago());
                        request.getRequestDispatcher("view/Pagos.jsp").forward(request, response);
                        break;
                    case "eliminar": break;
                    case "actualizar": break;
                }

            } else {
                switch (accion){
                    case "update":

                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void setViewContent(HttpServletRequest request, Pago pago) throws SQLException {
        request.setAttribute("pago", pago);
    }
    private void listaPagos(HttpServletRequest request, HttpServletResponse response, ArrayList<Pago> pagos) throws ServletException, IOException {
        request.setAttribute("pagos", pagos);
        request.getRequestDispatcher("view/Pagos.jsp").forward(request, response);
    }
    private Pago getPagoFromForm(HttpServletRequest request) {
        Pago pago = new Pago();

        pago.setIdPago(request.getParameter("txtpago"));
        pago.setMonto(Double.parseDouble(request.getParameter("txtmonto")));



        return pago;
    }
}
