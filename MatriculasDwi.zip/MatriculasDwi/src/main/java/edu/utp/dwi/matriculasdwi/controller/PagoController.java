package edu.utp.dwi.matriculasdwi.controller;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Pago;
import edu.utp.dwi.matriculasdwi.model.Profesor;
import edu.utp.dwi.matriculasdwi.model.dao.AlumnoApoderadoDAO;
import edu.utp.dwi.matriculasdwi.model.dao.PagoDAO;
import edu.utp.dwi.matriculasdwi.model.dao.ProfesorDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "PagoController", value = "/PagoController")
public class PagoController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("get", request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("post", request, response);
    }

    protected void processRequest(String method, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = "listar";
        if (request.getParameter("accion") != null) {
            accion = request.getParameter("accion");
        }
        String idPago="";
        if (request.getParameter("idPago") != null) {
            idPago = request.getParameter("idPago");
        }
        PagoDAO pagoDAO = new PagoDAO();
        AlumnoApoderadoDAO alumnoDAO = new AlumnoApoderadoDAO();
        try {
            if(method == "get"){
                switch (accion){
                    case "listar":
                        listaPagos(request, response, pagoDAO.listPago());
                        break;
                    case "editar":
                        listaAlumnos(request, response, alumnoDAO.listAlumno());
                        setViewContent(request, idPago != null ? pagoDAO.getPago(idPago) : new Pago());
                        request.getRequestDispatcher("view/EditarPagos.jsp").forward(request, response);
                        break;
                    case "eliminar":
                        pagoDAO.deletePago(idPago);
                        listaPagos(request, response, pagoDAO.listPago());
                        break;
                    case "buscar":
                        buscaPagos(request, response, pagoDAO.buscaPago(idPago));
                        break;

                }

            } else {
                switch (accion){
                    case "save":
                        if (pagoDAO.addPago(getPagoFromForm(request))) {
                            listaPagos(request, response, pagoDAO.listPago());

                        }else {
                            setViewContent(request, pagoDAO.getPago(idPago));
                            request.getRequestDispatcher("view/EditarPagos.jsp").forward(request, response);
                        }
                        break;
                    case "update":
                        if (pagoDAO.updatePago(getPagoFromForm(request))) {
                            listaPagos(request, response, pagoDAO.listPago());
                        } else {
                            setViewContent(request, pagoDAO.getPago(idPago));
                            request.getRequestDispatcher("view/EditarPagos.jsp").forward(request, response);
                        }
                        break;
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void listaPagos(HttpServletRequest request, HttpServletResponse response, ArrayList<Pago> pagos) throws ServletException, IOException {
        request.setAttribute("pagos", pagos);
        request.getRequestDispatcher("view/Pagos.jsp").forward(request, response);
    }
    private void buscaPagos(HttpServletRequest request, HttpServletResponse response, ArrayList<Pago> pagos) throws ServletException, IOException {
        request.setAttribute("pagos", pagos);
        request.getRequestDispatcher("view/Pagos.jsp").forward(request, response);
    }
    private void setViewContent(HttpServletRequest request, Pago pago) throws SQLException {
        request.setAttribute("pago", pago);
    }
    private void listaAlumnos(HttpServletRequest request, HttpServletResponse response, ArrayList<Alumno> alumnos) throws ServletException, IOException {
        request.setAttribute("alumnos", alumnos);
        request.getRequestDispatcher("view/EditarPagos.jsp").forward(request, response);
    }
    private Pago getPagoFromForm(HttpServletRequest request) {
        Pago pago = new Pago();
        pago.setIdPago(request.getParameter("txtpago"));
        pago.setAlumDni(request.getParameter("txtAlumno"));
        pago.setFecha(request.getParameter("txtFecha"));
        pago.setMonto(Double.parseDouble(request.getParameter("txtmonto")));
        pago.setVoucher(request.getParameter("txtVoucher"));

        return pago;
    }
}
