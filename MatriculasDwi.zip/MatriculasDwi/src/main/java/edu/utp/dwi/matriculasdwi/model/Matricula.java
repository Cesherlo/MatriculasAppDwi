package edu.utp.dwi.matriculasdwi.model;

public class Matricula {
}
