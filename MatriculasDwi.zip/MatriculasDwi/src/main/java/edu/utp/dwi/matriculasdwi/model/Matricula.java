package edu.utp.dwi.matriculasdwi.model;

public class Matricula {
    String matriculaId;
    String gradoId;
    String matriculaFecha;
    String pagoId;

    /*------*/
    String alumnoNombre;
    String alumnoApellido;

    public Matricula() {
    }

    /*constructor para base de datos*/
    public Matricula(String matriculaId, String gradoId, String matriculaFecha, String pagoId) {
        this.matriculaId = matriculaId;
        this.gradoId = gradoId;
        this.matriculaFecha = matriculaFecha;
        this.pagoId = pagoId;
    }

    /*constructor para listar detalladamente*/
    public Matricula(String matriculaId, String gradoId, String matriculaFecha, String pagoId, String alumnoNombre, String alumnoApellido) {
        this.matriculaId = matriculaId;
        this.gradoId = gradoId;
        this.matriculaFecha = matriculaFecha;
        this.pagoId = pagoId;
        this.alumnoNombre = alumnoNombre;
        this.alumnoApellido = alumnoApellido;
    }

    public String generarIdMatricula(){
        String id="";
        int random = (int)(Math.random()*(9999-1000+1)+1000);
        id = "MA-"+random;
        return id;
    }

    public String getMatriculaId() {
        return matriculaId;
    }

    public void setMatriculaId(String matriculaId) {
        this.matriculaId = matriculaId;
    }

    public String getGradoId() {
        return gradoId;
    }

    public void setGradoId(String gradoId) {
        this.gradoId = gradoId;
    }

    public String getMatriculaFecha() {
        return matriculaFecha;
    }

    public void setMatriculaFecha(String matriculaFecha) {
        this.matriculaFecha = matriculaFecha;
    }

    public String getPagoId() {
        return pagoId;
    }

    public void setPagoId(String pagoId) {
        this.pagoId = pagoId;
    }

    public String getAlumnoNombre() {
        return alumnoNombre;
    }

    public void setAlumnoNombre(String alumnoNombre) {
        this.alumnoNombre = alumnoNombre;
    }

    public String getAlumnoApellido() {
        return alumnoApellido;
    }

    public void setAlumnoApellido(String alumnoApellido) {
        this.alumnoApellido = alumnoApellido;
    }
}
