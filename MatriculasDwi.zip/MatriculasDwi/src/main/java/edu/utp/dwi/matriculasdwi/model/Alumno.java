package edu.utp.dwi.matriculasdwi.model;

import java.io.InputStream;

public class Alumno{
    int alumDni;
    String alumNom;
    String alumApe;
    String alumNac;
    String alunGen;
    String alumDis;
    String alumDir;
    String alumPro;
    int alumTel;
    String alumCorreo;
    InputStream alumFoto;
    String alumObs;

    /* apoderado */
    int apodDni;
    String apodNomb;
    String apodApel;
    String apodNac;
    String apodGen;
    int apodTel;
    String apodCor;

    public Alumno() {
    }

    public Alumno(int alumDni, String alumNom, String alumApe, String alumNac, String alunGen, String alumDis, String alumDir, String alumPro, int alumTel, String alumCorreo, InputStream alumFoto, String alumObs) {
        this.alumDni = alumDni;
        this.alumNom = alumNom;
        this.alumApe = alumApe;
        this.alumNac = alumNac;
        this.alunGen = alunGen;
        this.alumDis = alumDis;
        this.alumDir = alumDir;
        this.alumPro = alumPro;
        this.alumTel = alumTel;
        this.alumCorreo = alumCorreo;
        this.alumFoto = alumFoto;
        this.alumObs = alumObs;
    }

    public Alumno(int alumDni, String alumNom, String alumApe, String alumNac, String alunGen, String alumDis, String alumDir, String alumPro, int alumTel, String alumCorreo, InputStream alumFoto, String alumObs, int apodDni, String apodNomb, String apodApel, String apodNac, String apodGen, int apodTel, String apodCor) {
        this.alumDni = alumDni;
        this.alumNom = alumNom;
        this.alumApe = alumApe;
        this.alumNac = alumNac;
        this.alunGen = alunGen;
        this.alumDis = alumDis;
        this.alumDir = alumDir;
        this.alumPro = alumPro;
        this.alumTel = alumTel;
        this.alumCorreo = alumCorreo;
        this.alumFoto = alumFoto;
        this.alumObs = alumObs;
        this.apodDni = apodDni;
        this.apodNomb = apodNomb;
        this.apodApel = apodApel;
        this.apodNac = apodNac;
        this.apodGen = apodGen;
        this.apodTel = apodTel;
        this.apodCor = apodCor;
    }


    public int getAlumDni() {
        return alumDni;
    }

    public void setAlumDni(int alumDni) {
        this.alumDni = alumDni;
    }

    public String getAlumNom() {
        return alumNom;
    }

    public void setAlumNom(String alumNom) {
        this.alumNom = alumNom;
    }

    public String getAlumApe() {
        return alumApe;
    }

    public void setAlumApe(String alumApe) {
        this.alumApe = alumApe;
    }

    public String getAlumNac() {
        return alumNac;
    }

    public void setAlumNac(String alumNac) {
        this.alumNac = alumNac;
    }

    public String getAlunGen() {
        return alunGen;
    }

    public void setAlunGen(String alunGen) {
        this.alunGen = alunGen;
    }

    public String getAlumDis() {
        return alumDis;
    }

    public void setAlumDis(String alumDis) {
        this.alumDis = alumDis;
    }

    public String getAlumDir() {
        return alumDir;
    }

    public void setAlumDir(String alumDir) {
        this.alumDir = alumDir;
    }

    public String getAlumPro() {
        return alumPro;
    }

    public void setAlumPro(String alumPro) {
        this.alumPro = alumPro;
    }

    public int getAlumTel() {
        return alumTel;
    }

    public void setAlumTel(int alumTel) {
        this.alumTel = alumTel;
    }

    public String getAlumCorreo() {
        return alumCorreo;
    }

    public void setAlumCorreo(String alumCorreo) {
        this.alumCorreo = alumCorreo;
    }

    public InputStream getAlumFoto() {
        return alumFoto;
    }

    public void setAlumFoto(InputStream alumFoto) {
        this.alumFoto = alumFoto;
    }

    public String getAlumObs() {
        return alumObs;
    }

    public void setAlumObs(String alumObs) {
        this.alumObs = alumObs;
    }

    public int getApodDni() {
        return apodDni;
    }

    public void setApodDni(int apodDni) {
        this.apodDni = apodDni;
    }

    public String getApodNomb() {
        return apodNomb;
    }

    public void setApodNomb(String apodNomb) {
        this.apodNomb = apodNomb;
    }

    public String getApodApel() {
        return apodApel;
    }

    public void setApodApel(String apodApel) {
        this.apodApel = apodApel;
    }

    public String getApodNac() {
        return apodNac;
    }

    public void setApodNac(String apodNac) {
        this.apodNac = apodNac;
    }

    public String getApodGen() {
        return apodGen;
    }

    public void setApodGen(String apodGen) {
        this.apodGen = apodGen;
    }

    public int getApodTel() {
        return apodTel;
    }

    public void setApodTel(int apodTel) {
        this.apodTel = apodTel;
    }

    public String getApodCor() {
        return apodCor;
    }

    public void setApodCor(String apodCor) {
        this.apodCor = apodCor;
    }
}
