package edu.utp.dwi.matriculasdwi.model;

public class Pago {
    String idPago;
    int alumDni;
    String fecha;
    double monto;
    String voucher;

    public Pago() {
    }

    public Pago(String idPago, int alumDni, String fecha, double monto, String voucher) {
        this.idPago = idPago;
        this.alumDni = alumDni;
        this.fecha = fecha;
        this.monto = monto;
        this.voucher = voucher;
    }

    public String generarIdpago(int alumDni){
        String idpago="";
        int subDni= alumDni % 100000;
        idpago = "P" + subDni;
        return idpago;
    }

    public String getIdPago() {
        return idPago;
    }

    public void setIdPago(String idPago) {
        this.idPago = idPago;
    }

    public int getAlumDni() {
        return alumDni;
    }

    public void setAlumDni(int alumDni) {
        this.alumDni = alumDni;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }
}
