package edu.utp.dwi.matriculasdwi.model;

public class Pago {
    String idPago;
    String alumDni;
    String fecha;
    double monto;
    String voucher;
    String nombreAlumno;
    String nombreApellido;
    public Pago() {
    }
    public Pago(String idPago, String alumDni, String fecha, double monto, String voucher) {
        this.idPago = idPago;
        this.alumDni = alumDni;
        this.fecha = fecha;
        this.monto = monto;
        this.voucher = voucher;
    }

    public Pago(String idPago, String alumDni, String fecha, double monto, String voucher, String nombreAlumno, String nombreApellido) {
        this.idPago = idPago;
        this.alumDni = alumDni;
        this.fecha = fecha;
        this.monto = monto;
        this.voucher = voucher;
        this.nombreAlumno = nombreAlumno;
        this.nombreApellido = nombreApellido;
    }

    public String generarIdpago(String alumDni){
        String idpago="";
        String subDni = alumDni.substring(0,5);
        idpago = "P" + subDni;
        return idpago;
    }

    public String getNombreApellido() {
        return nombreApellido;
    }

    public void setNombreApellido(String nombreApellido) {
        this.nombreApellido = nombreApellido;
    }

    public String getIdPago() {
        return idPago;
    }

    public void setIdPago(String idPago) {
        this.idPago = idPago;
    }

    public String getAlumDni() {
        return alumDni;
    }

    public void setAlumDni(String alumDni) {
        this.alumDni = alumDni;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }

    public String getNombreAlumno() {
        return nombreAlumno;
    }

    public void setNombreAlumno(String nombreAlumno) {
        this.nombreAlumno = nombreAlumno;
    }
}
