package edu.utp.dwi.matriculasdwi.model;

import java.io.InputStream;

public class GenerarPDF {
    String alumDni;
    String alumNom;
    String alumApe;
    String alumNac;
    String alumDis;
    String alumDir;
    String alumPro;
    String alumTel;
    String apodDni;
    String apodNomb;
    String apodApel;
    String apodNac;
    String apodTel;
    String matriculaId;
    String matriculaFecha;
    String gradoNombre;
    String profNombres;
    String profApellidos;


    public GenerarPDF(String alumDni, String alumNom, String alumApe, String alumNac, String alumDis, String alumDir, String alumPro, String alumTel, String apodDni, String apodNomb, String apodApel, String apodNac, String apodTel, String matriculaId, String matriculaFecha, String gradoNombre, String profNombres, String profApellidos) {
        this.alumDni = alumDni;
        this.alumNom = alumNom;
        this.alumApe = alumApe;
        this.alumNac = alumNac;
        this.alumDis = alumDis;
        this.alumDir = alumDir;
        this.alumPro = alumPro;
        this.alumTel = alumTel;
        this.apodDni = apodDni;
        this.apodNomb = apodNomb;
        this.apodApel = apodApel;
        this.apodNac = apodNac;
        this.apodTel = apodTel;
        this.matriculaId = matriculaId;
        this.matriculaFecha = matriculaFecha;
        this.gradoNombre = gradoNombre;
        this.profNombres = profNombres;
        this.profApellidos = profApellidos;
    }

    public GenerarPDF() {
    }

    public String getAlumDni() {
        return alumDni;
    }

    public void setAlumDni(String alumDni) {
        this.alumDni = alumDni;
    }

    public String getAlumNom() {
        return alumNom;
    }

    public void setAlumNom(String alumNom) {
        this.alumNom = alumNom;
    }

    public String getAlumApe() {
        return alumApe;
    }

    public void setAlumApe(String alumApe) {
        this.alumApe = alumApe;
    }

    public String getAlumNac() {
        return alumNac;
    }

    public void setAlumNac(String alumNac) {
        this.alumNac = alumNac;
    }

    public String getAlumDis() {
        return alumDis;
    }

    public void setAlumDis(String alumDis) {
        this.alumDis = alumDis;
    }

    public String getAlumDir() {
        return alumDir;
    }

    public void setAlumDir(String alumDir) {
        this.alumDir = alumDir;
    }

    public String getAlumPro() {
        return alumPro;
    }

    public void setAlumPro(String alumPro) {
        this.alumPro = alumPro;
    }

    public String getAlumTel() {
        return alumTel;
    }

    public void setAlumTel(String alumTel) {
        this.alumTel = alumTel;
    }

    public String getApodDni() {
        return apodDni;
    }

    public void setApodDni(String apodDni) {
        this.apodDni = apodDni;
    }

    public String getApodNomb() {
        return apodNomb;
    }

    public void setApodNomb(String apodNomb) {
        this.apodNomb = apodNomb;
    }

    public String getApodApel() {
        return apodApel;
    }

    public void setApodApel(String apodApel) {
        this.apodApel = apodApel;
    }

    public String getApodNac() {
        return apodNac;
    }

    public void setApodNac(String apodNac) {
        this.apodNac = apodNac;
    }

    public String getApodTel() {
        return apodTel;
    }

    public void setApodTel(String apodTel) {
        this.apodTel = apodTel;
    }

    public String getMatriculaId() {
        return matriculaId;
    }

    public void setMatriculaId(String matriculaId) {
        this.matriculaId = matriculaId;
    }

    public String getMatriculaFecha() {
        return matriculaFecha;
    }

    public void setMatriculaFecha(String matriculaFecha) {
        this.matriculaFecha = matriculaFecha;
    }

    public String getGradoNombre() {
        return gradoNombre;
    }

    public void setGradoNombre(String gradoNombre) {
        this.gradoNombre = gradoNombre;
    }

    public String getProfNombres() {
        return profNombres;
    }

    public void setProfNombres(String profNombres) {
        this.profNombres = profNombres;
    }

    public String getProfApellidos() {
        return profApellidos;
    }

    public void setProfApellidos(String profApellidos) {
        this.profApellidos = profApellidos;
    }
}
