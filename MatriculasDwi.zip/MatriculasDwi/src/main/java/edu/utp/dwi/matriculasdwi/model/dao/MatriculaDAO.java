package edu.utp.dwi.matriculasdwi.model.dao;

public class MatriculaDAO {
}
