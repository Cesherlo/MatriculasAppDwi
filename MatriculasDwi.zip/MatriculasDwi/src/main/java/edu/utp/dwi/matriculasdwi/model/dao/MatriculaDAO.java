package edu.utp.dwi.matriculasdwi.model.dao;



import edu.utp.dwi.matriculasdwi.model.Matricula;
import edu.utp.dwi.matriculasdwi.model.Pago;

import java.sql.*;
import java.util.ArrayList;

public class MatriculaDAO implements IMatriculaDAO{
    static Connection connection = DBConnection.getConnection();

    @Override
    public boolean addMatricula(Matricula matricula) throws SQLException {
        String query = "{ CALL SP_AgregarMatricula(?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, matricula.generarIdMatricula());
        statement.setString(2, matricula.getGradoId());
        statement.setString(3, matricula.getMatriculaFecha());
        statement.setString(4, matricula.getPagoId());

        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public boolean updateMatricula(Matricula matricula) throws SQLException {
        String query = "{ CALL SP_ActualizarMatricula(?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, matricula.getMatriculaId());
        statement.setString(2, matricula.getGradoId());
        statement.setString(3, matricula.getMatriculaFecha());
        statement.setString(4, matricula.getPagoId());

        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public ArrayList<Matricula> listMatricula() throws SQLException {
        String query="SELECT M.MATRICULA_ID, M.GRADO_ID, M.MATRICULA_FECHA, M.PAGO_ID, A.ALUMNO_NOMBRES, A.ALUMNO_APELLIDOS FROM MATRICULA AS M INNER JOIN\n" +
                "PAGO AS P ON M.PAGO_ID = P.PAGO_ID INNER JOIN ALUMNO AS A ON P.ALUMNO_DNI = A.ALUMNO_DNI;";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Matricula> matricula = new ArrayList<>();

        while (resultSet.next()) {
            matricula.add(new Matricula(
                    resultSet.getString("MATRICULA_ID"),
                    resultSet.getString("GRADO_ID"),
                    resultSet.getString("MATRICULA_FECHA"),
                    resultSet.getString("PAGO_ID"),
                    resultSet.getString("ALUMNO_NOMBRES"),
                    resultSet.getString("ALUMNO_APELLIDOS")
            ));

        }
        return matricula;
    }

    @Override
    public Matricula getMatriculaId(String id) throws SQLException {
        Matricula matricula = null;
        String query = "{ CALL SP_SeleccionarMatricula(?) } ";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, id);
        ResultSet resultSet = statement.executeQuery();
        while(resultSet.next()) {
            matricula = new Matricula(
                    resultSet.getString("MATRICULA_ID"),
                    resultSet.getString("GRADO_ID"),
                    resultSet.getString("MATRICULA_FECHA"),
                    resultSet.getString("PAGO_ID"),
                    resultSet.getString("ALUMNO_NOMBRES"),
                    resultSet.getString("ALUMNO_APELLIDOS")
            );
        }

        return matricula;
    }

    @Override
    public boolean deleteMatricula(String id) throws SQLException {
        String query = "{ CALL SP_EliminarMatricula(?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, id);
        statement.execute();
        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public ArrayList<Matricula> BuscaMatricula(String id) throws SQLException {
        String query="{ CALL SP_BuscarMatricula(?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, id);
        ResultSet resultSet = statement.executeQuery();

        ArrayList<Matricula> matricula = new ArrayList<>();

        while (resultSet.next()) {
            matricula.add(new Matricula(
                    resultSet.getString("MATRICULA_ID"),
                    resultSet.getString("GRADO_ID"),
                    resultSet.getString("MATRICULA_FECHA"),
                    resultSet.getString("PAGO_ID"),
                    resultSet.getString("ALUMNO_NOMBRES"),
                    resultSet.getString("ALUMNO_APELLIDOS")
            ));

        }
        return matricula;
    }
}
