package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Pago;
import edu.utp.dwi.matriculasdwi.model.Profesor;

import java.sql.*;
import java.util.ArrayList;

public class PagoDAO implements IPagoDAO{
    static Connection connection = DBConnection.getConnection();
    @Override
    public boolean addPago(Pago pago) throws SQLException {
        String query = "{ CALL SP_AgregarPago(?,?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, pago.generarIdpago(pago.getAlumDni()));
        statement.setString(2, pago.getAlumDni());
        statement.setString(3, pago.getFecha());
        statement.setDouble(4, pago.getMonto());
        statement.setString(5, pago.getVoucher());
        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public boolean updatePago(Pago pago) throws SQLException {
        String query = "{ CALL SP_ActualizarPago(?,?,?,?,?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, pago.getIdPago());
        statement.setString(2, pago.getAlumDni());
        statement.setString(3, pago.getFecha());
        statement.setDouble(4, pago.getMonto());
        statement.setString(5, pago.getVoucher());

        statement.execute();

        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public ArrayList<Pago> listPago() throws SQLException {
        String query="select P.PAGO_ID,P.ALUMNO_DNI,A.ALUMNO_NOMBRES,A.ALUMNO_APELLIDOS,P.PAGO_FECHA,P.PAGO_MONTO,P.PAGO_BOUCHER from pago AS P INNER JOIN ALUMNO AS A WHERE P.ALUMNO_DNI = A.ALUMNO_DNI;";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Pago> pago = new ArrayList<>();

        while (resultSet.next()) {
            pago.add(new Pago(
                    resultSet.getString("PAGO_ID"),
                    resultSet.getString("ALUMNO_DNI"),
                    resultSet.getString("PAGO_FECHA"),
                    resultSet.getDouble("PAGO_MONTO"),
                    resultSet.getString("PAGO_BOUCHER"),
                    resultSet.getString("ALUMNO_NOMBRES"),
                    resultSet.getString("ALUMNO_APELLIDOS")

            ));

        }
        return pago;
    }

    public Pago getPago(String CodPago) throws SQLException {
        Pago pago = null;
        String query = "select PAGO_ID, ALUMNO_DNI, PAGO_FECHA, PAGO_MONTO, PAGO_BOUCHER FROM PAGO WHERE PAGO_ID=" + CodPago;
        PreparedStatement pStatement = connection.prepareStatement(query);
        ResultSet resultSet = pStatement.executeQuery();
        while(resultSet.next()) {
            pago = new Pago(
                    resultSet.getString("PAGO_ID"),
                    resultSet.getString("ALUMNO_DNI"),
                    resultSet.getString("PAGO_FECHA"),
                    resultSet.getDouble("PAGO_MONTO"),
                    resultSet.getString("PAGO_BOUCHER")
            );
        }

        return pago;
    }

    @Override
    public boolean deletePago(String idPago) throws SQLException {
        String query = "{ CALL SP_EliminarPago(?) }";

        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, idPago);

        statement.execute();
        int rowsAffected = statement.getUpdateCount();

        return rowsAffected > 0;
    }

    @Override
    public ArrayList<Pago> buscaPago(String id) throws SQLException {
        String query="{ CALL SP_BuscarPago(?) }";
        CallableStatement statement = connection.prepareCall(query);
        statement.setString(1, id);
        ResultSet resultSet = statement.executeQuery();

        ArrayList<Pago> pago = new ArrayList<>();

        while (resultSet.next()) {
            pago.add(new Pago(
                    resultSet.getString("PAGO_ID"),
                    resultSet.getString("ALUMNO_DNI"),
                    resultSet.getString("PAGO_FECHA"),
                    resultSet.getDouble("PAGO_MONTO"),
                    resultSet.getString("PAGO_BOUCHER"),
                    resultSet.getString("ALUMNO_NOMBRES"),
                    resultSet.getString("ALUMNO_APELLIDOS")

            ));

        }
        return pago;
    }

}
