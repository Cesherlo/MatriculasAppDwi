package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Pago;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PagoDAO implements IPagoDAO{
    static Connection connection = DBConnection.getConnection();
    @Override
    public void addPago(Pago pago) throws SQLException {

    }

    @Override
    public ArrayList<Pago> listPago() throws SQLException {
        String query="select * from pago";

        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Pago> pago = new ArrayList<>();

        while (resultSet.next()) {
            pago.add(new Pago(
                    resultSet.getString("PAGO_ID"),
                    resultSet.getInt("ALUMNO_DNI"),
                    resultSet.getString("PAGO_FECHA"),
                    resultSet.getDouble("PAGO_MONTO"),
                    resultSet.getString("PAGO_BOUCHER")

            ));

        }
        return pago;
    }

    public Pago getPago(int CodPago) throws SQLException {
        Pago pago = null;
        String query = "select PAGO_ID, ALUMNO_DNI, PAGO_FECHA, PAGO_MONTO, PAGO_BOUCHER FROM PAGO WHERE PAGO_ID=" + CodPago;
        PreparedStatement pStatement = connection.prepareStatement(query);
        ResultSet resultSet = pStatement.executeQuery();
        while(resultSet.next()) {
            pago = new Pago(
                    resultSet.getString("PAGO_ID"),
                    resultSet.getInt("ALUMNO_DNI"),
                    resultSet.getString("PAGO_FECHA"),
                    resultSet.getDouble("PAGO_MONTO"),
                    resultSet.getString("PAGO_BOUCHER")
            );
        }

        return pago;
    }

}
