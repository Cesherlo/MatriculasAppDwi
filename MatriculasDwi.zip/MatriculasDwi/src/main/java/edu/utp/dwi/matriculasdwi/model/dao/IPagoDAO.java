package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Pago;
import edu.utp.dwi.matriculasdwi.model.Profesor;

import java.sql.SQLException;
import java.util.ArrayList;

public interface IPagoDAO {

    boolean addPago(Pago pago) throws SQLException;

    boolean updatePago(Pago pago) throws SQLException;

    ArrayList<Pago> listPago() throws SQLException;

    Pago getPago(String pago) throws SQLException;

    boolean deletePago(String id) throws SQLException;

    ArrayList<Pago> buscaPago(String id) throws SQLException;
}
