package edu.utp.dwi.matriculasdwi.model.dao;

import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Pago;

import java.sql.SQLException;
import java.util.ArrayList;

public interface IPagoDAO {
    //Insertar Pago
    void addPago(Pago pago) throws SQLException;

    // Selecionar todos los Pagos
    ArrayList<Pago> listPago() throws SQLException;

    Pago getPago(int pago) throws SQLException;
}
