package edu.utp.dwi.matriculasdwi.model.dao;

public interface IMatriculaDAO {
}
