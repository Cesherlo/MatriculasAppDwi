package edu.utp.dwi.matriculasdwi.model.dao;


import edu.utp.dwi.matriculasdwi.model.Matricula;

import java.sql.SQLException;
import java.util.ArrayList;

public interface IMatriculaDAO {
    boolean addMatricula (Matricula matricula) throws SQLException;

    boolean updateMatricula(Matricula matricula) throws SQLException;

    ArrayList<Matricula> listMatricula() throws SQLException;

    Matricula getMatriculaId(String id) throws SQLException;

    boolean deleteMatricula(String id) throws SQLException;

    ArrayList<Matricula> BuscaMatricula(String id) throws SQLException;
}
