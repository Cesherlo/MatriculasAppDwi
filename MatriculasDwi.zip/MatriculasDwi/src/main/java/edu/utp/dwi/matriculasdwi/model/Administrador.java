package edu.utp.dwi.matriculasdwi.model;

public class Administrador {
    String admDni;
    String admUsuario;
    String admClave;
    String admNombres;
    String admApellidos;
    String admTelefono;


    public Administrador() {
    }

    public Administrador(String admDni, String admUsuario, String admClave, String admNombres, String admApellidos, String admTelefono) {
        this.admDni = admDni;
        this.admUsuario = admUsuario;
        this.admClave = admClave;
        this.admNombres = admNombres;
        this.admApellidos = admApellidos;
        this.admTelefono = admTelefono;
    }



    public String getAdmDni() {
        return admDni;
    }

    public void setAdmDni(String admDni) {
        this.admDni = admDni;
    }

    public String getAdmUsuario() {
        return admUsuario;
    }

    public void setAdmUsuario(String admUsuario) {
        this.admUsuario = admUsuario;
    }

    public String getAdmClave() {
        return admClave;
    }

    public void setAdmClave(String admClave) {
        this.admClave = admClave;
    }

    public String getAdmNombres() {
        return admNombres;
    }

    public void setAdmNombres(String admNombres) {
        this.admNombres = admNombres;
    }

    public String getAdmApellidos() {
        return admApellidos;
    }

    public void setAdmApellidos(String admApellidos) {
        this.admApellidos = admApellidos;
    }

    public String getAdmTelefono() {
        return admTelefono;
    }

    public void setAdmTelefono(String admTelefono) {
        this.admTelefono = admTelefono;
    }
}
