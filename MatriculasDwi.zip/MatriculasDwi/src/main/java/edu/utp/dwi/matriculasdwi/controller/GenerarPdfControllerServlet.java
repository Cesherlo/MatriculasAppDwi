package edu.utp.dwi.matriculasdwi.controller;


import edu.utp.dwi.matriculasdwi.model.GenerarPDF;
import edu.utp.dwi.matriculasdwi.model.Matricula;
import edu.utp.dwi.matriculasdwi.model.dao.GenerarpdfDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "GenerarPdfControllerServlet", value = "/GenerarPdfControllerServlet")
public class GenerarPdfControllerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("get", request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("post", request, response);
    }

    protected void processRequest(String method, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = "listar";
        if (request.getParameter("accion") != null) {
            accion = request.getParameter("accion");
        }
        String idMatricula = "";
        if (request.getParameter("idMatricula") != null) {
            idMatricula =request.getParameter("idMatricula");
        }
        GenerarpdfDAO generarpdfDAO = new GenerarpdfDAO();

        try {
            if(method == "get"){
                switch (accion){
                    case "generar":
                        setViewContent(request, response, idMatricula.length() > 0 ? generarpdfDAO.getRegistro(idMatricula) : new GenerarPDF());
                        request.getRequestDispatcher("view/GenerarPDF.jsp").forward(request, response);
                        break;

                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void setViewContent(HttpServletRequest request,HttpServletResponse response, GenerarPDF generarPDF) throws SQLException, ServletException, IOException {
        request.setAttribute("datos", generarPDF);

    }


}
