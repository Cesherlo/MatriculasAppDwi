package edu.utp.dwi.matriculasdwi.controller;


import edu.utp.dwi.matriculasdwi.model.Alumno;
import edu.utp.dwi.matriculasdwi.model.Grado;
import edu.utp.dwi.matriculasdwi.model.Profesor;
import edu.utp.dwi.matriculasdwi.model.dao.GradoDAO;
import edu.utp.dwi.matriculasdwi.model.dao.ProfesorDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "GradoController", value = "/GradoController")
public class GradoController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("get", request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest("post", request, response);
    }
    protected void processRequest(String method, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = "listar";
        if (request.getParameter("accion") != null) {
            accion = request.getParameter("accion");
        }
        String idGrado = "";
        if (request.getParameter("idGrado") != null ){
            idGrado = request.getParameter("idGrado");
        }
        GradoDAO gradoDAO = new GradoDAO();
        ProfesorDAO profesorDAO = new ProfesorDAO();
        try {
            if(method == "get"){
                switch (accion){
                    case "listar":
                        listaGrado(request, response, gradoDAO.listGrado());
                        break;
                    case "editar":

                        setViewContent(request, idGrado.length() > 0 ? gradoDAO.getGradoId(idGrado) :  new Grado() );

                        listaProfesores(request, response, profesorDAO.listProfesor());



                        break;
                    case "eliminar":
                        gradoDAO.deleteGrado(idGrado);
                        listaGrado(request, response, gradoDAO.listGrado());
                        break;
                }

            } else {
                switch (accion) {
                    case "save":
                        if (gradoDAO.addGrado(getGradoFromForm(request))) {
                            listaGrado(request, response, gradoDAO.listGrado());
                        } else {
                            setViewContent(request, gradoDAO.getGradoId(idGrado));
                            request.getRequestDispatcher("view/EditarGrado.jsp").forward(request, response);
                        }
                        break;
                    case "update":
                        if (gradoDAO.updateGrado(getGradoFromForm(request))) {
                            listaGrado(request, response, gradoDAO.listGrado());
                        } else {
                            setViewContent(request, gradoDAO.getGradoId(idGrado));
                            request.getRequestDispatcher("view/EditarGrado.jsp").forward(request, response);
                        }
                        break;
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void setViewContent(HttpServletRequest request, Grado grado) throws SQLException {
        request.setAttribute("grado", grado);
    }
    private void listaProfesores(HttpServletRequest request, HttpServletResponse response, ArrayList<Profesor> profesor) throws ServletException, IOException {
        request.setAttribute("profesor", profesor);
        request.getRequestDispatcher("view/EditarGrado.jsp").forward(request, response);
    }
    private void listaGrado(HttpServletRequest request, HttpServletResponse response, ArrayList<Grado> grado) throws ServletException, IOException {
        request.setAttribute("grado", grado);
        request.getRequestDispatcher("view/Grados.jsp").forward(request, response);
    }

    private Grado getGradoFromForm(HttpServletRequest request) {
        Grado grado = new Grado();
        grado.setGradoId(request.getParameter("txtIdGrado"));
        grado.setGradoNombre(request.getParameter("txtNombreGrado"));
        grado.setProfesorDni(request.getParameter("txtProfesor"));
        return grado;
    }
}
